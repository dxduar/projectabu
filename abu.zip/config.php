<?php

// list
$inputList = 'list.txt'; // list.txt

// telegram
$telegramToken = '1718549962:AAGcLUAP5d2ECwH2ALpqpEQVug6DE04O-og'; // token telegram bot
$telegramChatId = '467874951'; // chat id telegram